Make An Application Here: https://discord.com/developers/applications/
----------------------------------------------------------------------
Copy The Token!
---------------
Extract Zip Bot Files Into Desktop!
-----------------------------------
Copy The Token From Application To The Bot's Config (config.json)!
------------------------------------------------------------------
Choose A Collor From Here :https://pinetools.com/image-color-picker And Place It On (ColorID) With # To Bot's Config (config.json)
----------------------------------------------------------------------------------------------------------------------------------
Copy Your Bots (Client ID) Paste It Here : https://discordapi.com/permissions.html And Select Administrator Permissions!
------------------------------------------------------------------------------------------------------------------------
Then Click The Link And Add It To Your Discord Server!
------------------------------------------------------
Open Your cmd : WindowsKey+R Type cmd ENTER or Press WindowsKey Type cmd ENTER! -> And Type
-------------------------------------------------------------------------------------------
cd desktop
cd wfs-donate
node .
--------------
Your Bot Will Come Online!
--------------------------
Have Fun Support Me Dope#8595!!! 


